EP4 - MAC0121

Aluno: Daniel Silva Lopes da Costa
N°USP 11302720

Para rodar o programa, implemente o "make".
Em seguida use "./ep4" para iniciar a implementação.
O programa irá pedir para entrar com o nome de uma arquivo válido.
Nessa pasta temos quatro arquivos de teste, com tamanhos variados:
ex1.txt
ex2.txt
ex3.txt
ex4.txt

Os números foram considerados com palavra também. Por exemplo se houver 2004 no texto ele será contado como uma palavra.